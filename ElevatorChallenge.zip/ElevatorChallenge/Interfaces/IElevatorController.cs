﻿
using System;
using System.Collections.Generic;

namespace ElevatorChallenge.Interfaces
{
    public interface IElevatorController
    {
        Task RunAsync();
    }
}

