﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using ElevatorChallenge.Interfaces;
using ElevatorChallenge.Entities;
using ElevatorChallenge.Configuration;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace ElevatorChallenge.Service
{
    public class ElevatorController : IElevatorController
    {
        private readonly ILogger<ElevatorController> _logger;
        private readonly IBuilding _building;
        private readonly ElevatorSettings _settings;

        public ElevatorController(
            ILogger<ElevatorController> logger,
            IBuilding building,
            IOptions<ElevatorSettings> settings)
        {
            _logger = logger;
            _building = building;
            _settings = settings.Value;
        }

        public async Task RunAsync()
        {
            _logger.LogInformation("Elevator Controller started with {DefaultElevators} elevators and {DefaultFloors} floors",
                _settings.DefaultElevators, _settings.DefaultFloors);

            // Display initial status
            DisplayStatus();

            // Simple interactive loop
            while (true)
            {
                Console.WriteLine("\n=== ELEVATOR CONTROL ===");
                Console.WriteLine("1. Request elevator");
                Console.WriteLine("2. Show status");
                Console.WriteLine("3. Exit");
                Console.Write("Select option: ");

                var input = Console.ReadLine();

                if (input == "1")
                {
                    await HandleElevatorRequest();
                }
                else if (input == "2")
                {
                    DisplayStatus();
                }
                else if (input == "3")
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid option. Please try again.");
                }

                // Update all elevators
                UpdateAllElevators();

                // delay to see elevator movements
                await Task.Delay(500);
            }

            _logger.LogInformation("Elevator Simulation completed");
        }

        private async Task HandleElevatorRequest()
        {
            Console.Write("Enter floor number: ");
            if (!int.TryParse(Console.ReadLine(), out int floor) || floor < 1 || floor > _settings.DefaultFloors)
            {
                Console.WriteLine($"Invalid floor. Please enter a number between 1 and {_settings.DefaultFloors}.");
                return;
            }

            Console.Write("Enter number of passengers: ");
            if (!int.TryParse(Console.ReadLine(), out int passengers) || passengers < 1)
            {
                Console.WriteLine("Invalid passenger count. Please enter a positive number.");
                return;
            }

            // Find the best elevator for this request
            var bestElevator = FindBestElevatorForRequest(floor, passengers);
            if (bestElevator != null)
            {
                Console.WriteLine($"Assigning Elevator {bestElevator.Id} to your request...");
                await bestElevator.AddDestinationAsync(floor, passengers);

                // Show elevator movement
                Console.WriteLine($"Elevator {bestElevator.Id} is now {GetStatusDescription(bestElevator.State)}");
            }
            else
            {
                Console.WriteLine("No available elevator found for your request. Please try again later.");
            }
        }

        private string GetStatusDescription(ElevatorStatus status)
        {
            switch (status)
            {
                case ElevatorStatus.GoingUp: return "going UP ↑";
                case ElevatorStatus.GoingDown: return "going DOWN ↓";
                case ElevatorStatus.Idle: return "IDLE";
                case ElevatorStatus.DoorsOpen: return "DOORS OPEN";
                default: return status.ToString();
            }
        }

        private void DisplayStatus()
        {
            Console.WriteLine("\n=== ELEVATOR STATUS ===");

            foreach (var elevator in _building.Elevators)
            {
                string directionSymbol = "";
                if (elevator.State == ElevatorStatus.GoingUp) directionSymbol = "↑";
                if (elevator.State == ElevatorStatus.GoingDown) directionSymbol = "↓";

                Console.WriteLine($"Elevator {elevator.Id} ({elevator.Type}): " +
                                  $"Floor {elevator.CurrentFloor} {directionSymbol}, " +
                                  $"State: {elevator.State}, " +
                                  $"Passengers: {elevator.PassengerCount}/{elevator.Capacity}, " +
                                  $"Destinations: {string.Join(",", elevator.DestinationFloors)}");
            }

            // Show waiting passengers per floor
            Console.WriteLine("\nWaiting passengers by floor:");
            for (int i = 1; i <= _settings.DefaultFloors; i++)
            {
                int waiting = _building.GetWaitingPassengers(i);
                if (waiting > 0)
                {
                    Console.WriteLine($"Floor {i}: {waiting} passengers waiting");
                }
            }
        }

        private IElevator FindBestElevatorForRequest(int floor, int passengers)
        {
            // find the closest available elevator
            var availableElevators = _building.Elevators
                .Where(e => e.PassengerCount + passengers <= e.Capacity)
                .ToList();

            if (!availableElevators.Any())
                return null;

            // Find the elevator closest to the requested floor
            return availableElevators
                .OrderBy(e => Math.Abs(e.CurrentFloor - floor))
                .First();
        }

        private void UpdateAllElevators()
        {
            foreach (var elevator in _building.Elevators)
            {
                elevator.Update();
            }
        }
    }
}